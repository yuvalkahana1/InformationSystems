from flask import Flask, render_template, redirect, request, session, url_for
from flask_session import Session
from datetime import timedelta, datetime # הוספתי datetime

app = Flask(__name__)

# הגדרות Session מתוקנות לפיתוח
app.config.update(
    SESSION_TYPE="filesystem",
    # SESSION_FILE_DIR="./flask_session_data", # נקודה לפני אומרת "בתיקייה הנוכחית"
    SESSION_PERMANENT=True,
    PERMANENT_SESSION_LIFETIME=timedelta(minutes=10),
    SESSION_COOKIE_SECURE=False # חייב להיות False כדי שיעבוד ב-localhost
)

Session(app)

# בסיס נתונים זמני - שים לב למבנה האחיד!
temp_db = {
    "Donald@mail.tau.ac.il": {
        "password": "123!@ABC",
        "full_name": "דונלד טראמפ"
    }
}

@app.route("/")
def home_page():
    return render_template("home_page.html")

@app.route("/user_home_page")
def user_home_page():
    if 'email' not in session:
        return redirect("/login")
    return render_template("user_home_page.html")

@app.route("/login", methods=["POST","GET"])
def login():
    if request.method == "POST":
        email = request.form.get("email")  # unique value
        password = request.form.get("password")
        if temp_db.get(email) == password:
            session['email'] = email
            return redirect("/user_home_page")
        else:
            return render_template("login.html", message='Incorrect Login Details.')
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        full_name = request.form.get("full_name")
        email = request.form.get("email")
        phone = request.form.get("phone")
        birth_date = request.form.get("birth_date")
        passport = request.form.get("passport")
        password = request.form.get("password")

        if not all([full_name, email, phone, birth_date, passport, password]):
            return render_template("register.html", message="נא למלא את כל השדות")

        if email in temp_db:
            return render_template("register.html", message="אימייל כבר קיים במערכת")

        temp_db[email] = {     #לחבר לDB שלנו
            "full_name": full_name,
            "phone": phone,
            "birth_date": birth_date,
            "passport": passport,
            "password": password,
            "register_date": datetime.now().strftime("%Y-%m-%d %H:%M")
        }

        session['email'] = email
        return redirect("/login")

    return render_template("register.html")
if __name__=="__main__":
    app.run(debug=True)